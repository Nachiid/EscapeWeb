</br></br>
<!-- Footer -->
    <div class="footer">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="footer-col first">
              <h6>About Website</h6>
                <p class="p-small">Aliquam ultrices turpis a auctor commodo. Etiam consectetur tincidunt elit ac euismod. Duis et finibus felis, non porttitor dolor</p>
                  </div> <!-- end of footer-col -->
                    <div class="footer-col second">
                      <h6>Links</h6>
                      <ul class="list-unstyled li-space-lg p-small">
                        <li>Important: <a href="terms.html">Terms & Conditions</a>, <a href="privacy.html">Privacy Policy</a></li>
                        <li>Useful: <a href="#">Colorpicker</a>, <a href="#">Icon Library</a>, <a href="#">Illustrations</a></li>
                        <li>Menu: <a href="index.html">Home</a>, <a href="#solutions">Solutions</a>, <a href="#expertise">Expertise</a>, <a href="#projects">Projects</a></li>
                      </ul>
                      </div> <!-- end of footer-col -->
                      <div class="footer-col third">
                        <span class="fa-stack">
                          <a href="#your-link">
                            <i class="fas fa-circle fa-stack-2x"></i>
                            <i class="fab fa-facebook-f fa-stack-1x"></i>
                          </a>
                          </span>
                          <span class="fa-stack">
                          <a href="#your-link">
                            <i class="fas fa-circle fa-stack-2x"></i>
                            <i class="fab fa-twitter fa-stack-1x"></i>
                          </a>
                        </span>
                        <span class="fa-stack">
                          <a href="#your-link">
                            <i class="fas fa-circle fa-stack-2x"></i>
                            <i class="fab fa-pinterest-p fa-stack-1x"></i>
                           </a>
                        </span>
                        <span class="fa-stack">
                          <a href="#your-link">
                            <i class="fas fa-circle fa-stack-2x"></i>
                            <i class="fab fa-instagram fa-stack-1x"></i>
                          </a>
                        </span>
                        <p class="p-small">Pour nous contacter <a href="mailto:contact@site.com"><strong>contact@site.com</strong></a></p>
                      </div> <!-- end of footer-col -->
                    </div> <!-- end of col -->
                </div> <!-- end of row -->
            </div> <!-- end of container -->
        </div> <!-- end of footer -->  
        <!-- end of footer -->
        <!-- Copyright -->
      <div class="copyright">
        <div class="container">
          <div class="row">
            <div class="col-lg-12">
                  <p class="p-small">Copyright © <a href="#your-link">Aymen</a></p>
            </div> <!-- end of col -->
          </div> <!-- enf of row -->
        </div> <!-- end of container -->
      </div> <!-- end of copyright --> 
        <!-- end of copyright -->        
        <!-- Back To Top Button -->
        <button onclick="topFunction()" id="myBtn">
            <img src="bootstrap/images/up-arrow.png" alt="alternative">
        </button>
        <!-- end of back to top button -->            
        <!-- Scripts -->
        <link rel="stylesheet" href="<?php echo base_url();?>bootstrap/js/bootstrap.min.js"><!-- Bootstrap framework -->
        <link rel="stylesheet" href="<?php echo base_url();?>bootstrap/js/swiper.min.js"><!-- Swiper for image and text sliders -->
        <link rel="stylesheet" href="<?php echo base_url();?>bootstrap/js/purecounter.min.js"><!-- Purecounter counter for statistics numbers -->
        <link rel="stylesheet" href="<?php echo base_url();?>bootstrap/js/replaceme.min.js"><!-- ReplaceMe for rotating text -->
        <link rel="stylesheet" href="<?php echo base_url();?>bootstrap/js/isotope.pkgd.min.js"><!-- Isotope for filter -->
        <link rel="stylesheet" href="<?php echo base_url();?>bootstrap/js/scripts.js"><!-- Custom scripts -->
  </body>
</html>