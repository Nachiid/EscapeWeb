<?php
redirect()->to(route_to('compte/afficher_profil')); ?>