<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />

    <!-- SEO Meta Tags -->
    <meta name="description" content="Your description" />
    <meta name="author" content="Your name" />

    <!-- OG Meta Tags to improve the way the post looks when you share the page on Facebook, Twitter, LinkedIn -->
    <meta property="og:site_name" content="" />
    <!-- website name -->
    <meta property="og:site" content="" />
    <!-- website link -->
    <meta property="og:title" content="" />
    <!-- title shown in the actual shared post -->
    <meta property="og:description" content="" />
    <!-- description shown in the actual shared post -->
    <meta property="og:image" content="" />
    <!-- image link, make sure it's jpg -->
    <meta property="og:url" content="" />
    <!-- where do you want your post to link to -->
    <meta name="twitter:card" content="summary_large_image" />
    <!-- to have large image post format in Twitter -->

    <!-- Webpage Title -->
    <title>Webpage Title</title>

    <!-- Styles -->
    <link
      href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,400;0,600;0,700;1,400&family=Poppins:wght@600&display=swap"
      rel="stylesheet"
    />
    <link href="css/bootstrap.min.css" rel="stylesheet" />
    <link href="css/fontawesome-all.min.css" rel="stylesheet" />
    <link href="css/swiper.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />

    <!-- Favicon  -->
    <link rel="icon" href="images/favicon.png" />
  </head>
  <body data-bs-spy="scroll" data-bs-target="#navbarExample">
    <!-- Navigation -->
    <nav
      id="navbarExample"
      class="navbar navbar-expand-lg fixed-top navbar-dark"
      aria-label="Main navigation"
    >
    <?php
            echo ("Page Web OK");
            // Connexion à la base MariaDB
            $mysqli = new mysqli('localhost','e22111435sql','7sptj75J','e22111435_db1');
            if ($mysqli->connect_errno) {
                echo ("Erreur cnx  BD");
            }
            //Préparation du mot de passe de l’utilisateur tuxie
            $userspassword = "CeciEstMonMotdePasse!123";
            // On rajoute du sel...
            // pour empêcher les attaques par "Rainbow Tables" cf
            // http://en.wikipedia.org/wiki/Rainbow_table
            $salt = "OnRajouteDuSelPourAllongerleMDP123!!45678__Test";
            // Le mot de passe rallongé sera donc :
            // OnRajouteDuSelPourAllongerleMDP123!!45678__TestCeciEstMonMotdePasse!123
            $password = hash('sha256', $salt.$userspassword);
            echo $password;
            // Constitution par concaténation d'une requête UPDATE + exécution
            $requete ="UPDATE T_compte_cpt SET cpt_mdp='".$password."'  WHERE
            cpt_email='aymennachid@gmail.com';";
            echo($requete);
            $resultat=$mysqli->query($requete);
            /*Modification du mot de passe du profil de login tuxie*/
            if (!$resultat) { 
                // La requête a echoué ... 
            } 
            else { 
                // La requête a réussi...
             } 
          /*  $img_name = "SELECT sce_image from T_scenario_sce WHERE sce_id = '1' "; 
            if($result = $mysqli->query($img_name)){ if($result->num_rows >0) { $row = $result -> fetch_assoc(); echo ''; } } 
            else { echo 'ERRER : ' . $mysqli->error ; } //Fermeture de la communication avec la base MariaDB $mysqli->close(); */?>
      
      
      <div class="container">
        <!-- Image Logo -->
        <a class="navbar-brand logo-image" href="index.html"
          ><img src="images/logo.svg" alt="alternative"
        /></a>

        <!-- Text Logo - Use this if you don't have a graphic logo -->
        <!-- <a class="navbar-brand logo-text" href="index.html">Vera</a> -->

        <button
          class="navbar-toggler p-0 border-0"
          type="button"
          id="navbarSideCollapse"
          aria-label="Toggle navigation"
        >
          <span class="navbar-toggler-icon"></span>
        </button>

        <div
          class="navbar-collapse offcanvas-collapse"
          id="navbarsExampleDefault"
        >
          <ul class="navbar-nav ms-auto navbar-nav-scroll">
            <li class="nav-item">
              <a class="nav-link" href="#header">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#solutions">Solutions</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#details">Details</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#expertise">Expertise</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#pricing">Pricing</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#projects">Projects</a>
            </li>
            <li class="nav-item dropdown">
              <a
                class="nav-link dropdown-toggle"
                href="#"
                id="dropdown01"
                data-bs-toggle="dropdown"
                aria-expanded="false"
                >Drop</a
              >
              <ul class="dropdown-menu" aria-labelledby="dropdown01">
                <li>
                  <a class="dropdown-item" href="article.html"
                    >Article Details</a
                  >
                </li>
                <li><div class="dropdown-divider"></div></li>
                <li>
                  <a class="dropdown-item" href="terms.html"
                    >Terms Conditions</a
                  >
                </li>
                <li><div class="dropdown-divider"></div></li>
                <li>
                  <a class="dropdown-item" href="privacy.html"
                    >Privacy Policy</a
                  >
                </li>
              </ul>
            </li>
          </ul>
          <span class="nav-item social-icons">
            <span class="fa-stack">
              <a href="#your-link">
                <i class="fas fa-circle fa-stack-2x"></i>
                <i class="fab fa-facebook-f fa-stack-1x"></i>
              </a>
            </span>
            <span class="fa-stack">
              <a href="#your-link">
                <i class="fas fa-circle fa-stack-2x"></i>
                <i class="fab fa-twitter fa-stack-1x"></i>
              </a>
            </span>
          </span>
        </div>
        <!-- end of navbar-collapse -->
      </div>
      <!-- end of container -->
    </nav>
    <!-- end of navbar -->
    <!-- end of navigation -->

    <!-- Header -->
    <header id="header" class="header">
      <div class="container">
        <div class="row">
          <div class="col-lg-6">
            <div class="text-container">
              <h1 class="h1-large">
                HEY JOIN ME FOR
                <span class="replace-me">FUN, JOY, EPICNESS</span>
              </h1>
              <p class="p-large">
                Lorem ipsum dolor sit amet consectetur adipiscing elit donec sit
                amet lectus id erat hendrerit ullamcorper cras compale
              </p>
              <a class="btn-solid-lg page-scroll" href="#solutions"
                >Learn More</a
              >
            </div>
            <!-- end of text-container -->
          </div>
          <!-- end of col -->
        </div>
        <!-- end of row -->
      </div>
      <!-- end of container -->
      <img
        class="vertical-decoration"
        src="images/vertical-decoration-left.svg"
        alt="alternative"
      />
    </header>
    <!-- end of header -->
    <!-- end of header -->

    <!-- Partners -->
    <div class="slider-1">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <!-- <p class="p-small">OUR PARTNERS</p> -->

            <!-- Image Slider -->
            <div class="slider-container">
              <div class="swiper-container image-slider">
                <div class="swiper-wrapper">
                  <div class="swiper-slide">
                    <img
                      class="img-fluid"
                      src="images/partner-logo-1.png"
                      alt="alternative"
                    />
                  </div>
                  <div class="swiper-slide">
                    <img
                      class="img-fluid"
                      src="images/JOJO.png"
                      alt="alternative"
                    />
                  </div>
                  <div class="swiper-slide">
                    <img
                      class="img-fluid"
                      src="images/partner-logo-6.png"
                      alt="alternative"
                    />
                  </div>
                  <div class="swiper-slide">
                    <img
                      class="img-fluid"
                      src="images/pngegg (1).png"
                      alt="alternative"
                    />
                  </div>
                  <div class="swiper-slide">
                    <img
                      class="img-fluid"
                      src="images/partner-logo-5.png"
                      alt="alternative"
                    />
                  </div>
                  <div class="swiper-slide">
                    <img
                      class="img-fluid"
                      src="
                      images/LEVI.png"
                      alt="alternative"
                    />
                  </div>
                </div>
                <!-- end of swiper-wrapper -->
              </div>
              <!-- end of swiper container -->
            </div>
            <!-- end of slider-container -->
            <!-- end of image slider -->
          </div>
          <!-- end of col -->
        </div>
        <!-- end of row -->
      </div>
      <!-- end of container -->
    </div>
    <!-- end of slider-1 -->
    <!-- end of partners -->

    <!-- Registration -->
    <div id="registration" class="form-1">
      <div class="container">
        <div class="row">
          <div class="col-lg-6">
            <div class="text-container">
              <h2>Just Fill Out The Form And We’ll Call You</h2>
              <hr class="hr-heading" />
              <p>
                Mauris nec imperdiet sagittis, risus ligula posuere enim, ac
                eleife ligula ligula sit amet velit Morbi varius ante quis
                libero blandit auctor. Phasellus rhoncus varius nulla nec
                tristique mares
              </p>
              <ul class="list-unstyled li-space-lg">
                <li class="d-flex">
                  <i class="fas fa-square"></i>
                  <div class="flex-grow-1">
                    <strong>Vi basi</strong> ligula sit amet velit Morbi varius
                    ante quis dino
                  </div>
                </li>
                <li class="d-flex">
                  <i class="fas fa-square"></i>
                  <div class="flex-grow-1">
                    <strong>Phasellus</strong> rhoncus varius nulla nec
                    tristique ro vones
                  </div>
                </li>
                <li class="d-flex">
                  <i class="fas fa-square"></i>
                  <div class="flex-grow-1">
                    <strong>Risus fo</strong> ligula posuere enim, ac eleife
                    ligula nem malo
                  </div>
                </li>
              </ul>
            </div>
            <!-- end of text-container -->
          </div>
          <!-- end of col -->
          <div class="col-lg-6">
            <!-- Registration Form -->
            <form>
              <div class="mb-4 form-floating">
                <input
                  type="text"
                  class="form-control"
                  id="floatingInput1"
                  placeholder="Name"
                />
                <label for="floatingInput1">Name</label>
              </div>
              <div class="mb-4 form-floating">
                <input
                  type="email"
                  class="form-control"
                  id="floatingInput2"
                  placeholder="name@example.com"
                />
                <label for="floatingInput2">Email</label>
              </div>
              <div class="mb-4 form-floating">
                <input
                  type="text"
                  class="form-control"
                  id="floatingInput3"
                  placeholder="Phone"
                />
                <label for="floatingInput3">Phone</label>
              </div>
              <div class="mb-4 input-group">
                <select class="form-select" id="inputGroupSelect1">
                  <option selected>Interested in...</option>
                  <option value="ERP solution">ACTION</option>
                  <option value="CRM solution">CRM solution</option>
                  <option value="SFA solution">SFA solution</option>
                  <option value="WMS solution">WMS solution</option>
                </select>
              </div>
              <div class="mb-4 form-check">
                <input
                  type="checkbox"
                  class="form-check-input"
                  id="exampleCheck1"
                />
                <label class="form-check-label" for="exampleCheck1"
                  >Varius nulla nec
                  <a href="privacy.html">Privacy Policy</a> los ve
                  <a href="terms.html">Terms & Conditions</a></label
                >
              </div>
              <button type="submit" class="form-control-submit-button">
                Inquire
              </button>
            </form>
            <!-- end of registrations form -->
          </div>
          <!-- end of col -->
        </div>
        <!-- end of row -->
      </div>
      <!-- end of container -->
    </div>
    <!-- end of form-1 -->
    <!-- end of registration -->

    <!-- Solutions -->
    <div id="solutions" class="cards-1">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="section-title">
              <div class="title">SOLUTIONS</div>
            </div>
            <!-- end of section-title -->
            <h2 class="h2-heading">
              Vera Provides Software Solutions For Business Acceleration
            </h2>
          </div>
          <!-- end of col -->
        </div>
        <!-- end of row -->
        <div class="row">
          <div class="col-lg-12">
            <!-- Card -->
            <div class="card">
              <div class="card-image">
                <img
                  class="img-fluid"
                  src="images/solution-1.jpg"
                  alt="alternative"
                />
              </div>
              <div class="card-body">
                <h4 class="card-title">ERP Software Solution</h4>
                <p>
                  Phasellus rhoncus varius nulla nec tristique. Vivamus quis re
                  placerat nisi duis suscipit feugiat neque eget finibus elit
                  nom efficitur et. Nullam non tincidunt dui vitae aliquet regs
                </p>
                <div class="tag">MANAGEMENT</div>
              </div>
            </div>
            <!-- end of card -->

            <!-- Card -->
            <div class="card">
              <div class="card-image">
                <img
                  class="img-fluid"
                  src="images/solution-2.jpg"
                  alt="alternative"
                />
              </div>
              <div class="card-body">
                <h4 class="card-title">CRM Software Solution</h4>
                <p>
                  Phasellus rhoncus varius nulla nec tristique. Vivamus quis re
                  placerat nisi duis suscipit feugiat neque eget finibus elit
                  nom efficitur et. Nullam non tincidunt dui vitae aliquet regs
                </p>
                <div class="tag">MARKETING</div>
              </div>
            </div>
            <!-- end of card -->

            <!-- Card -->
            <div class="card">
              <div class="card-image">
                <img
                  class="img-fluid"
                  src="images/solution-3.jpg"
                  alt="alternative"
                />
              </div>
              <div class="card-body">
                <h4 class="card-title">SFA Software Solution</h4>
                <p>
                  Phasellus rhoncus varius nulla nec tristique. Vivamus quis re
                  placerat nisi duis suscipit feugiat neque eget finibus elit
                  nom efficitur et. Nullam non tincidunt dui vitae aliquet regs
                </p>
                <div class="tag">DISTRIBUTION</div>
              </div>
            </div>
            <!-- end of card -->

            <!-- Card -->
            <div class="card">
              <div class="card-image">
                <img
                  class="img-fluid"
                  src="images/solution-4.jpg"
                  alt="alternative"
                />
              </div>
              <div class="card-body">
                <h4 class="card-title">WMS Software Solution</h4>
                <p>
                  Phasellus rhoncus varius nulla nec tristique. Vivamus quis re
                  placerat nisi duis suscipit feugiat neque eget finibus elit
                  nom efficitur et. Nullam non tincidunt dui vitae aliquet regs
                </p>
                <div class="tag">WAREHOUSE</div>
              </div>
            </div>
            <!-- end of card -->
          </div>
          <!-- end of col -->
        </div>
        <!-- end of row -->
      </div>
      <!-- end of container -->
    </div>
    <!-- end of cards-1 -->
    <!-- end of solutions -->

    <!-- Details 1 -->
    <div id="details" class="basic-1">
      <div class="container">
        <div class="row">
          <div class="col-lg-5">
            <div class="text-container">
              <h2>Evaluation And Deployment Service</h2>
              <hr class="hr-heading" />
              <p>
                Suspendisse luctus eu libero ac vulputate. Ut sollicitudin leo a
                nisi ornare, sit amet bibendum mi tristique. Ut vel mattis enim
                <a href="#your-link">romantro velumde</a>
              </p>
              <ul class="list-unstyled li-space-lg">
                <li class="d-flex">
                  <i class="fas fa-square"></i>
                  <div class="flex-grow-1">
                    <strong>Donec ullamcorper</strong> at eros vestibulum mina
                  </div>
                </li>
                <li class="d-flex">
                  <i class="fas fa-square"></i>
                  <div class="flex-grow-1">
                    <strong>Aenean luctus, nibh</strong> nec dapibus tempus,
                    ligul
                  </div>
                </li>
              </ul>
              <!-- end of list-unstyled -->
            </div>
            <!-- end of text-container -->
          </div>
          <!-- end of col -->
          <div class="col-lg-7">
            <div class="image-container">
              <img
                class="img-fluid"
                src="images/details-1.jpg"
                alt="alternative"
              />
            </div>
            <!-- end of image-container -->
          </div>
          <!-- end of col -->
        </div>
        <!-- end of row -->
      </div>
      <!-- end of container -->
      <img
        class="vertical-decoration"
        src="images/vertical-decoration-left.svg"
        alt="alternative"
      />
    </div>
    <!-- end of basic-1 -->
    <!-- end of details 1 -->

    <!-- Details 2 -->
    <div class="basic-2">
      <div class="container">
        <div class="row">
          <div class="col-lg-7">
            <div class="image-container">
              <img
                class="img-fluid"
                src="images/details-2.jpg"
                alt="alternative"
              />
            </div>
            <!-- end of image-container -->
          </div>
          <!-- end of col -->
          <div class="col-lg-5">
            <div class="text-container">
              <h2>Maintenance And Support Services</h2>
              <hr class="hr-heading" />
              <p>
                Suspendisse luctus eu libero ac vulputate. Ut sollicitudin leo a
                nisi ornare, sit amet bibendum mi tristique. Ut vel mattis enim
                <a href="#your-link">romantro velumde</a>
              </p>
              <ul class="list-unstyled li-space-lg">
                <li class="d-flex">
                  <i class="fas fa-square"></i>
                  <div class="flex-grow-1">
                    <strong>Donec ullamcorper</strong> at eros vestibulum mina
                  </div>
                </li>
                <li class="d-flex">
                  <i class="fas fa-square"></i>
                  <div class="flex-grow-1">
                    <strong>Aenean luctus, nibh</strong> nec dapibus tempus,
                    ligul
                  </div>
                </li>
              </ul>
              <!-- end of list-unstyled -->
            </div>
            <!-- end of text-container -->
          </div>
          <!-- end of col -->
        </div>
        <!-- end of row -->
      </div>
      <!-- end of container -->
      <img
        class="vertical-decoration"
        src="images/vertical-decoration-right.svg"
        alt="alternative"
      />
    </div>
    <!-- end of basic-2 -->
    <!-- end of details 2 -->

    <!-- Expertise -->
    <div id="expertise" class="cards-2">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="section-title">
              <div class="title">EXPERTISE</div>
            </div>
            <!-- end of box-heading-wrapper -->
            <h2 class="h2-heading">Expertise Strong Points</h2>
            <p class="p-heading">
              Curabitur ante dolor, euismod a arcu nec, pellentesque sodales
              nunc. Ut a libero nunc. Nunc hendrerit nunc vel lorem volutpat,
              nec lobortis dolor tincidunts
            </p>
          </div>
          <!-- end of col -->
        </div>
        <!-- end of row -->
        <div class="row">
          <div class="col-lg-12">
            <!-- Card -->
            <div class="card">
              <div class="card-image">
                <i class="fas fa-lightbulb"></i>
              </div>
              <div class="card-body">
                <h4 class="card-title">Flexible Services</h4>
                <p>Morbi blandit felis at pharetra facilisis nullam necro</p>
              </div>
            </div>
            <!-- end of card -->

            <!-- Card -->
            <div class="card">
              <div class="card-image">
                <i class="fas fa-wifi"></i>
              </div>
              <div class="card-body">
                <h4 class="card-title">Great Design</h4>
                <p>Morbi blandit felis at pharetra facilisis nullam necro</p>
              </div>
            </div>
            <!-- end of card -->

            <!-- Card -->
            <div class="card">
              <div class="card-image">
                <i class="fas fa-desktop"></i>
              </div>
              <div class="card-body">
                <h4 class="card-title">Easy To Use</h4>
                <p>Morbi blandit felis at pharetra facilisis nullam necro</p>
              </div>
            </div>
            <!-- end of card -->

            <!-- Card -->
            <div class="card">
              <div class="card-image">
                <i class="fas fa-cog"></i>
              </div>
              <div class="card-body">
                <h4 class="card-title">Smart Options</h4>
                <p>Morbi blandit felis at pharetra facilisis nullam necro</p>
              </div>
            </div>
            <!-- end of card -->

            <!-- Card -->
            <div class="card">
              <div class="card-image">
                <i class="fas fa-glasses"></i>
              </div>
              <div class="card-body">
                <h4 class="card-title">Advanced Tech</h4>
                <p>Morbi blandit felis at pharetra facilisis nullam necro</p>
              </div>
            </div>
            <!-- end of card -->

            <!-- Card -->
            <div class="card">
              <div class="card-image">
                <i class="fas fa-graduation-cap"></i>
              </div>
              <div class="card-body">
                <h4 class="card-title">Good Expertise</h4>
                <p>Morbi blandit felis at pharetra facilisis nullam necro</p>
              </div>
            </div>
            <!-- end of card -->

            <!-- Card -->
            <div class="card">
              <div class="card-image">
                <i class="fas fa-chart-bar"></i>
              </div>
              <div class="card-body">
                <h4 class="card-title">Detailed Reports</h4>
                <p>Morbi blandit felis at pharetra facilisis nullam necro</p>
              </div>
            </div>
            <!-- end of card -->

            <!-- Card -->
            <div class="card">
              <div class="card-image">
                <i class="fas fa-cloud"></i>
              </div>
              <div class="card-body">
                <h4 class="card-title">Cloud Storage</h4>
                <p>Morbi blandit felis at pharetra facilisis nullam necro</p>
              </div>
            </div>
            <!-- end of card -->
          </div>
          <!-- end of col -->
        </div>
        <!-- end of row -->
      </div>
      <!-- end of container -->
    </div>
    <!-- end of cards-1 -->
    <!-- end of expertise -->

    <!-- Video -->
    <div class="basic-3">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <!-- Video Preview -->
            <div class="image-container">
              <div class="video-wrapper">
                <img
                  class="img-fluid"
                  src="images/video-preview.jpg"
                  alt="alternative"
                />
                <a
                  class="video-btn"
                  data-bs-toggle="modal"
                  data-bs-target="#videoModal"
                  data-bs-src="https://www.youtube.com/embed/fLCjQJCekTs"
                >
                  <span class="video-play-button">
                    <span></span>
                  </span>
                </a>
              </div>
              <!-- end of video-wrapper -->
            </div>
            <!-- end of image-container -->
            <!-- end of video preview -->
          </div>
          <!-- end of col -->
        </div>
        <!-- end of row -->
        <div class="row">
          <div class="col-lg-4">
            <div class="text-container">
              <h4>10 Years Of Experience</h4>
              <p>
                Felis eget lectus consequat rutrum suspendi felis elit, interdum
                at eros eget valomre
              </p>
            </div>
            <!-- end of text-container -->
          </div>
          <!-- end of col -->
          <div class="col-lg-4">
            <div class="text-container">
              <h4>Enduring Partnerships</h4>
              <p>
                Felis eget lectus consequat rutrum suspendi felis elit, interdum
                at eros eget valomre
              </p>
            </div>
            <!-- end of text-container -->
          </div>
          <!-- end of col -->
          <div class="col-lg-4">
            <div class="text-container">
              <h4>Skilled Capable Team</h4>
              <p>
                Felis eget lectus consequat rutrum suspendi felis elit, interdum
                at eros eget valomre
              </p>
            </div>
            <!-- end of text-container -->
          </div>
          <!-- end of col -->
        </div>
        <!-- end of row -->
      </div>
      <!-- end of container -->
    </div>
    <!-- end of basic-3 -->
    <!-- end of video -->

    <!-- Video Modal -->
    <div class="video-modal">
      <div
        class="modal fade"
        id="videoModal"
        tabindex="-1"
        role="dialog"
        aria-hidden="true"
      >
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <button
              type="button"
              class="btn-close"
              data-bs-dismiss="modal"
              aria-label="Close"
            ></button>
            <div class="ratio ratio-16x9">
              <iframe
                class="embed-responsive-item"
                id="video"
                allow="autoplay"
              ></iframe>
            </div>
          </div>
          <!-- end of modal-content -->
        </div>
        <!-- end of modal-dialog -->
      </div>
      <!-- end of modal -->
    </div>
    <!-- end of video-modal -->
    <!-- end of video modal -->

    <!-- Pricing -->
    <div id="pricing" class="cards-3">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="section-title">
              <div class="title">PRICING</div>
            </div>
            <!-- end of box-heading-wrapper -->
            <h2 class="h2-heading">Flexible Pricing Options</h2>
          </div>
          <!-- end of col -->
        </div>
        <!-- end of row -->

        <div class="row">
          <div class="col-lg-12">
            <!-- Card -->
            <div class="card">
              <div class="card-body">
                <div class="price"><span class="currency">$</span>99</div>
                <h4 class="card-title">STANDARD</h4>
                <p>
                  Pellentesque sit amet ornare libero. In tristique tincidunt
                  placerat. In lacinia norem
                </p>
                <ul class="list-unstyled li-space-lg">
                  <li class="media">
                    <div class="media-body">
                      <strong>SUBSCRIBERS LIST</strong>
                    </div>
                  </li>
                  <li class="media">
                    <div class="media-body">
                      <strong>USER ADMIN CONTROL</strong>
                    </div>
                  </li>
                </ul>
                <a class="btn-solid-reg page-scroll" href="#registration"
                  >Inquire</a
                >
              </div>
            </div>
            <!-- end of card -->

            <!-- Card -->
            <div class="card">
              <div class="card-body">
                <div class="price"><span class="currency">$</span>199</div>
                <h4 class="card-title">ADVANCED</h4>
                <p>
                  Pellentesque sit amet ornare libero. In tristique tincidunt
                  placerat. In lacinia norem
                </p>
                <ul class="list-unstyled li-space-lg">
                  <li class="media">
                    <div class="media-body">
                      <strong>LIMITED STORAGE SPACE</strong>
                    </div>
                  </li>
                  <li class="media">
                    <div class="media-body">
                      <strong>FREE CLOUD STORAGE</strong>
                    </div>
                  </li>
                </ul>
                <a class="btn-solid-reg page-scroll" href="#registration"
                  >Inquire</a
                >
              </div>
            </div>
            <!-- end of card -->

            <!-- Card -->
            <div class="card">
              <div class="card-body">
                <div class="price"><span class="currency">$</span>299</div>
                <h4 class="card-title">COMPLETE</h4>
                <p>
                  Pellentesque sit amet ornare libero. In tristique tincidunt
                  placerat. In lacinia norem
                </p>
                <ul class="list-unstyled li-space-lg">
                  <li class="media">
                    <div class="media-body">
                      <strong>DEPLOYMENT PROTOCOL</strong>
                    </div>
                  </li>
                  <li class="media">
                    <div class="media-body">
                      <strong>PREMIUM SUPPORT PACK</strong>
                    </div>
                  </li>
                </ul>
                <a class="btn-solid-reg page-scroll" href="#registration"
                  >Inquire</a
                >
              </div>
            </div>
            <!-- end of card -->
          </div>
          <!-- end of col -->
        </div>
        <!-- end of row -->
      </div>
      <!-- end of container -->
    </div>
    <!-- end of cards-3 -->
    <!-- end of pricing -->

    <!-- Projects -->
    <div id="projects" class="filter">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="section-title">
              <div class="title">PROJECTS</div>
            </div>
            <!-- end of box-heading-wrapper -->
            <h2 class="h2-heading">Projects We're Proud Of</h2>
            <p class="p-heading">
              Fusce a rutrum quam. Aenean massa tortor, condimentum a suscipit
              eu, tristique eget sem. Pellentesque hendrerit nisl vel diam
              elementum, quis interdum
            </p>
          </div>
          <!-- end of col -->
        </div>
        <!-- end of row -->
        <div class="row">
          <div class="col-lg-12">
            <!-- Filter -->
            <div class="button-group filters-button-group">
              <button class="button is-checked" data-filter="*">
                SHOW ALL
              </button>
              <button class="button" data-filter=".erp">ERP</button>
              <button class="button" data-filter=".crm">CRM</button>
              <button class="button" data-filter=".sfa">SFA</button>
            </div>
            <!-- end of button group -->
            <div class="grid">
              <div class="element-item erp">
                <a data-bs-toggle="modal" data-bs-target="#modal1">
                  <img
                    class="img-fluid"
                    src="images/project-1.jpg"
                    alt="alternative"
                  />
                  <p>
                    <strong>Orkla Foods</strong> - Donec bibeum mollis liga sit
                    amet pulvinar sed viverra noris
                  </p>
                </a>
              </div>
              <div class="element-item erp">
                <a data-bs-toggle="modal" data-bs-target="#modal2">
                  <img
                    class="img-fluid"
                    src="images/project-2.jpg"
                    alt="alternative"
                  />
                  <p>
                    <strong>Alka Sweets</strong> - Donec bibeum mollis liga sit
                    amet pulvinar sed viverra noris
                  </p>
                </a>
              </div>
              <div class="element-item crm">
                <a data-bs-toggle="modal" data-bs-target="#modal3">
                  <img
                    class="img-fluid"
                    src="images/project-3.jpg"
                    alt="alternative"
                  />
                  <p>
                    <strong>First Bank</strong> - Donec bibeum mollis liga sit
                    amet pulvinar sed viverra noris
                  </p>
                </a>
              </div>
              <div class="element-item crm">
                <a data-bs-toggle="modal" data-bs-target="#modal4">
                  <img
                    class="img-fluid"
                    src="images/project-4.jpg"
                    alt="alternative"
                  />
                  <p>
                    <strong>Fast Courier</strong> - Donec bibeum mollis liga sit
                    amet pulvinar sed viverra noris
                  </p>
                </a>
              </div>
              <div class="element-item sfa">
                <a data-bs-toggle="modal" data-bs-target="#modal5">
                  <img
                    class="img-fluid"
                    src="images/project-5.jpg"
                    alt="alternative"
                  />
                  <p>
                    <strong>Lyra Market</strong> - Donec bibeum mollis liga sit
                    amet pulvinar sed viverra noris
                  </p>
                </a>
              </div>
              <div class="element-item sfa">
                <a data-bs-toggle="modal" data-bs-target="#modal6">
                  <img
                    class="img-fluid"
                    src="images/project-6.jpg"
                    alt="alternative"
                  />
                  <p>
                    <strong>Monday Stores</strong> - Donec bibeum mollis liga
                    sit amet pulvinar sed viverra
                  </p>
                </a>
              </div>
            </div>
            <!-- end of grid -->
            <!-- end of filter -->
          </div>
          <!-- end of col -->
        </div>
        <!-- end of row -->
      </div>
      <!-- end of container -->
    </div>
    <!-- end of filter -->
    <!-- end of projects -->

    <!-- Projects Modals -->
    <div class="projects-modals">
      <!-- Modal -->
      <div id="modal1" class="modal fade" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="row">
              <button
                type="button"
                class="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
              <div class="col-lg-6">
                <div class="image-container">
                  <img
                    class="img-fluid"
                    src="images/project-1.jpg"
                    alt="alternative"
                  />
                </div>
                <!-- end of image-container -->
              </div>
              <!-- end of col -->
              <div class="col-lg-6">
                <div class="text-container">
                  <h3>Orkla Foods</h3>
                  <p>
                    Aliquam at accumsan nibh. Praesent pretium ut tortor ac
                    commodo. Integer semper quam at rutrum interdum. Mauris eu
                    diam ac urna laoreet mollis et
                  </p>
                  <p>
                    Praesent lacus tortor, facilisis non enim eu, luctus semper
                    velit. Curabitur faucibus diam in lectus.
                  </p>
                  <a class="btn-solid-reg" href="#your-link">Details</a>
                  <button
                    type="button"
                    class="btn-outline-reg"
                    data-bs-dismiss="modal"
                  >
                    Close
                  </button>
                </div>
                <!-- end of text-container -->
              </div>
              <!-- end of col -->
            </div>
            <!-- end of row -->
          </div>
          <!-- end of modal-content -->
        </div>
        <!-- end of modal-dialog -->
      </div>
      <!-- end of modal -->
      <!-- end of modal -->

      <!-- Modal -->
      <div id="modal2" class="modal fade" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="row">
              <button
                type="button"
                class="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
              <div class="col-lg-6">
                <div class="image-container">
                  <img
                    class="img-fluid"
                    src="images/project-2.jpg"
                    alt="alternative"
                  />
                </div>
                <!-- end of image-container -->
              </div>
              <!-- end of col -->
              <div class="col-lg-6">
                <div class="text-container">
                  <h3>Alka Sweets</h3>
                  <p>
                    Aliquam at accumsan nibh. Praesent pretium ut tortor ac
                    commodo. Integer semper quam at rutrum interdum. Mauris eu
                    diam ac urna laoreet mollis et
                  </p>
                  <p>
                    Praesent lacus tortor, facilisis non enim eu, luctus semper
                    velit. Curabitur faucibus diam in lectus.
                  </p>
                  <a class="btn-solid-reg" href="#your-link">Details</a>
                  <button
                    type="button"
                    class="btn-outline-reg"
                    data-bs-dismiss="modal"
                  >
                    Close
                  </button>
                </div>
                <!-- end of text-container -->
              </div>
              <!-- end of col -->
            </div>
            <!-- end of row -->
          </div>
          <!-- end of modal-content -->
        </div>
        <!-- end of modal-dialog -->
      </div>
      <!-- end of modal -->
      <!-- end of modal -->

      <!-- Modal -->
      <div id="modal3" class="modal fade" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="row">
              <button
                type="button"
                class="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
              <div class="col-lg-6">
                <div class="image-container">
                  <img
                    class="img-fluid"
                    src="images/project-3.jpg"
                    alt="alternative"
                  />
                </div>
                <!-- end of image-container -->
              </div>
              <!-- end of col -->
              <div class="col-lg-6">
                <div class="text-container">
                  <h3>First Bank</h3>
                  <p>
                    Aliquam at accumsan nibh. Praesent pretium ut tortor ac
                    commodo. Integer semper quam at rutrum interdum. Mauris eu
                    diam ac urna laoreet mollis et
                  </p>
                  <p>
                    Praesent lacus tortor, facilisis non enim eu, luctus semper
                    velit. Curabitur faucibus diam in lectus.
                  </p>
                  <a class="btn-solid-reg" href="#your-link">Details</a>
                  <button
                    type="button"
                    class="btn-outline-reg"
                    data-bs-dismiss="modal"
                  >
                    Close
                  </button>
                </div>
                <!-- end of text-container -->
              </div>
              <!-- end of col -->
            </div>
            <!-- end of row -->
          </div>
          <!-- end of modal-content -->
        </div>
        <!-- end of modal-dialog -->
      </div>
      <!-- end of modal -->
      <!-- end of modal -->

      <!-- Modal -->
      <div id="modal4" class="modal fade" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="row">
              <button
                type="button"
                class="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
              <div class="col-lg-6">
                <div class="image-container">
                  <img
                    class="img-fluid"
                    src="images/project-4.jpg"
                    alt="alternative"
                  />
                </div>
                <!-- end of image-container -->
              </div>
              <!-- end of col -->
              <div class="col-lg-6">
                <div class="text-container">
                  <h3>Fast Courier</h3>
                  <p>
                    Aliquam at accumsan nibh. Praesent pretium ut tortor ac
                    commodo. Integer semper quam at rutrum interdum. Mauris eu
                    diam ac urna laoreet mollis et
                  </p>
                  <p>
                    Praesent lacus tortor, facilisis non enim eu, luctus semper
                    velit. Curabitur faucibus diam in lectus.
                  </p>
                  <a class="btn-solid-reg" href="#your-link">Details</a>
                  <button
                    type="button"
                    class="btn-outline-reg"
                    data-bs-dismiss="modal"
                  >
                    Close
                  </button>
                </div>
                <!-- end of text-container -->
              </div>
              <!-- end of col -->
            </div>
            <!-- end of row -->
          </div>
          <!-- end of modal-content -->
        </div>
        <!-- end of modal-dialog -->
      </div>
      <!-- end of modal -->
      <!-- end of modal -->

      <!-- Modal -->
      <div id="modal5" class="modal fade" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="row">
              <button
                type="button"
                class="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
              <div class="col-lg-6">
                <div class="image-container">
                  <img
                    class="img-fluid"
                    src="images/project-5.jpg"
                    alt="alternative"
                  />
                </div>
                <!-- end of image-container -->
              </div>
              <!-- end of col -->
              <div class="col-lg-6">
                <div class="text-container">
                  <h3>Lyra Market</h3>
                  <p>
                    Aliquam at accumsan nibh. Praesent pretium ut tortor ac
                    commodo. Integer semper quam at rutrum interdum. Mauris eu
                    diam ac urna laoreet mollis et
                  </p>
                  <p>
                    Praesent lacus tortor, facilisis non enim eu, luctus semper
                    velit. Curabitur faucibus diam in lectus.
                  </p>
                  <a class="btn-solid-reg" href="#your-link">Details</a>
                  <button
                    type="button"
                    class="btn-outline-reg"
                    data-bs-dismiss="modal"
                  >
                    Close
                  </button>
                </div>
                <!-- end of text-container -->
              </div>
              <!-- end of col -->
            </div>
            <!-- end of row -->
          </div>
          <!-- end of modal-content -->
        </div>
        <!-- end of modal-dialog -->
      </div>
      <!-- end of modal -->
      <!-- end of modal -->

      <!-- Modal -->
      <div id="modal6" class="modal fade" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="row">
              <button
                type="button"
                class="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
              <div class="col-lg-6">
                <div class="image-container">
                  <img
                    class="img-fluid"
                    src="images/project-6.jpg"
                    alt="alternative"
                  />
                </div>
                <!-- end of image-container -->
              </div>
              <!-- end of col -->
              <div class="col-lg-6">
                <div class="text-container">
                  <h3>Monday Stores</h3>
                  <p>
                    Aliquam at accumsan nibh. Praesent pretium ut tortor ac
                    commodo. Integer semper quam at rutrum interdum. Mauris eu
                    diam ac urna laoreet mollis et
                  </p>
                  <p>
                    Praesent lacus tortor, facilisis non enim eu, luctus semper
                    velit. Curabitur faucibus diam in lectus.
                  </p>
                  <a class="btn-solid-reg" href="#your-link">Details</a>
                  <button
                    type="button"
                    class="btn-outline-reg"
                    data-bs-dismiss="modal"
                  >
                    Close
                  </button>
                </div>
                <!-- end of text-container -->
              </div>
              <!-- end of col -->
            </div>
            <!-- end of row -->
          </div>
          <!-- end of modal-content -->
        </div>
        <!-- end of modal-dialog -->
      </div>
      <!-- end of modal -->
      <!-- end of modal -->
    </div>
    <!-- end of projects-modals -->
    <!-- end of projects modals -->

    <!-- Testimonials -->
    <div class="slider-2">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <!-- Card Slider -->
            <div class="slider-container">
              <div class="swiper-container card-slider">
                <div class="swiper-wrapper">
                  <!-- Slide -->
                  <div class="swiper-slide">
                    <div class="card">
                      <img
                        class="card-image"
                        src="images/testimonial-1.jpg"
                        alt="alternative"
                      />
                      <div class="card-body">
                        <p class="testimonial-text">
                          Mauris facilisis urna urna, non volutpat tortor
                          rhoncus nec. Vivamus consectetur dui quis libero
                          tempus ut eleifend
                        </p>
                        <p class="testimonial-author">Jude Thorn - Designer</p>
                      </div>
                    </div>
                  </div>
                  <!-- end of swiper-slide -->
                  <!-- end of slide -->

                  <!-- Slide -->
                  <div class="swiper-slide">
                    <div class="card">
                      <img
                        class="card-image"
                        src="images/testimonial-2.jpg"
                        alt="alternative"
                      />
                      <div class="card-body">
                        <p class="testimonial-text">
                          Mauris facilisis urna urna, non volutpat tortor
                          rhoncus nec. Vivamus consectetur dui quis libero
                          tempus ut eleifend
                        </p>
                        <p class="testimonial-author">Roy Smith - Developer</p>
                      </div>
                    </div>
                  </div>
                  <!-- end of swiper-slide -->
                  <!-- end of slide -->

                  <!-- Slide -->
                  <div class="swiper-slide">
                    <div class="card">
                      <img
                        class="card-image"
                        src="images/testimonial-3.jpg"
                        alt="alternative"
                      />
                      <div class="card-body">
                        <p class="testimonial-text">
                          Mauris facilisis urna urna, non volutpat tortor
                          rhoncus nec. Vivamus consectetur dui quis libero
                          tempus ut eleifend
                        </p>
                        <p class="testimonial-author">
                          Marsha Singer - Marketer
                        </p>
                      </div>
                    </div>
                  </div>
                  <!-- end of swiper-slide -->
                  <!-- end of slide -->

                  <!-- Slide -->
                  <div class="swiper-slide">
                    <div class="card">
                      <img
                        class="card-image"
                        src="images/testimonial-4.jpg"
                        alt="alternative"
                      />
                      <div class="card-body">
                        <p class="testimonial-text">
                          Mauris facilisis urna urna, non volutpat tortor
                          rhoncus nec. Vivamus consectetur dui quis libero
                          tempus ut eleifend
                        </p>
                        <p class="testimonial-author">Tim Shaw - Designer</p>
                      </div>
                    </div>
                  </div>
                  <!-- end of swiper-slide -->
                  <!-- end of slide -->

                  <!-- Slide -->
                  <div class="swiper-slide">
                    <div class="card">
                      <img
                        class="card-image"
                        src="images/testimonial-5.jpg"
                        alt="alternative"
                      />
                      <div class="card-body">
                        <p class="testimonial-text">
                          Mauris facilisis urna urna, non volutpat tortor
                          rhoncus nec. Vivamus consectetur dui quis libero
                          tempus ut eleifend
                        </p>
                        <p class="testimonial-author">
                          Lindsay Spice - Designer
                        </p>
                      </div>
                    </div>
                  </div>
                  <!-- end of swiper-slide -->
                  <!-- end of slide -->

                  <!-- Slide -->
                  <div class="swiper-slide">
                    <div class="card">
                      <img
                        class="card-image"
                        src="images/testimonial-6.jpg"
                        alt="alternative"
                      />
                      <div class="card-body">
                        <p class="testimonial-text">
                          Mauris facilisis urna urna, non volutpat tortor
                          rhoncus nec. Vivamus consectetur dui quis libero
                          tempus ut eleifend
                        </p>
                        <p class="testimonial-author">Ann Black - Developer</p>
                      </div>
                    </div>
                  </div>
                  <!-- end of swiper-slide -->
                  <!-- end of slide -->
                </div>
                <!-- end of swiper-wrapper -->

                <!-- Add Arrows -->
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
                <!-- end of add arrows -->
              </div>
              <!-- end of swiper-container -->
            </div>
            <!-- end of slider-container -->
            <!-- end of card slider -->
          </div>
          <!-- end of col -->
        </div>
        <!-- end of row -->
      </div>
      <!-- end of container -->
    </div>
    <!-- end of slider-2 -->
    <!-- end of testimonials -->

    <!-- Statistics -->
    <div class="counter">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <!-- Counter -->
            <div class="counter-container">
              <div class="counter-cell">
                <i class="fas fa-users"></i>
                <div
                  data-purecounter-start="0"
                  data-purecounter-end="231"
                  data-purecounter-duration="3"
                  class="purecounter"
                >
                  1
                </div>
                <div class="counter-info">Happy Customers</div>
              </div>
              <!-- end of counter-cell -->
              <div class="counter-cell">
                <i class="fas fa-code"></i>
                <div
                  data-purecounter-start="0"
                  data-purecounter-end="385"
                  data-purecounter-duration="1.5"
                  class="purecounter"
                >
                  1
                </div>
                <div class="counter-info">Issues Solved</div>
              </div>
              <!-- end of counter-cell -->
              <div class="counter-cell">
                <i class="fas fa-cog"></i>
                <div
                  data-purecounter-start="0"
                  data-purecounter-end="159"
                  data-purecounter-duration="3"
                  class="purecounter"
                >
                  1
                </div>
                <div class="counter-info">Good Reviews</div>
              </div>
              <!-- end of counter-cell -->
              <div class="counter-cell">
                <i class="fas fa-rocket"></i>
                <div
                  data-purecounter-start="0"
                  data-purecounter-end="128"
                  data-purecounter-duration="3"
                  class="purecounter"
                >
                  1
                </div>
                <div class="counter-info">Case Studies</div>
              </div>
              <!-- end of counter-cell -->
              <div class="counter-cell">
                <i class="fas fa-comments"></i>
                <div
                  data-purecounter-start="0"
                  data-purecounter-end="216"
                  data-purecounter-duration="3"
                  class="purecounter"
                >
                  1
                </div>
                <div class="counter-info">Press Articles</div>
              </div>
              <!-- end of counter-cell -->
            </div>
            <!-- end of counter-container -->
            <!-- end of counter -->
          </div>
          <!-- end of col -->
        </div>
        <!-- end of row -->
      </div>
      <!-- end of container -->
    </div>
    <!-- end of counter -->
    <!-- end of statistics -->

    <!-- Statement -->
    <div class="basic-4-wrapper">
      <div class="basic-4">
        <div class="container">
          <div class="row">
            <div class="col-lg-12">
              <div class="text-container">
                <h4>
                  Our Mission Is To Provide Reliable Business Solutions For
                  Companies Of All Sizes And Part Of Any Industry
                </h4>
                <a class="btn-outline-lg" href="#your-link">About Us</a>
              </div>
              <!-- end of text-container -->
            </div>
            <!-- end of col -->
          </div>
          <!-- end of row -->
        </div>
        <!-- end of container -->
      </div>
      <!-- end of basic-4 -->
    </div>
    <!-- end of basic-4-wrapper -->
    <!-- end of statement -->

    <!-- Newsletter -->
    <div class="form-2">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <h2 class="h2-heading">Subscribe And Follow</h2>
            <p class="p-heading">
              Aliquam luctus quam quis tristique tristique maecenas
              <a href="#your-link">@sitetweet</a> rhoncus luctus est
              <a href="#your-link">@sitefb</a> sagittis molestie. Morbi molestie
              posuere nome dank repet rino va
            </p>
          </div>
          <!-- end of col -->
        </div>
        <!-- end of row -->
        <div class="row">
          <div class="col-lg-12">
            <!-- Newsletter Form -->
            <form>
              <div class="mb-4 form-floating">
                <input
                  type="email"
                  class="form-control"
                  id="floatingInput4"
                  placeholder="name@example.com"
                />
                <label for="floatingInput4">Email address</label>
              </div>
              <button type="submit" class="form-control-submit-button">
                Subscribe
              </button>
            </form>
            <!-- end of newsletter form -->
          </div>
          <!-- end of col -->
        </div>
        <!-- end of row -->
      </div>
      <!-- end of container -->
    </div>
    <!-- end of form-2 -->
    <!-- end of newsletter -->

    <!-- Footer -->
    <div class="footer">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="footer-col first">
              <h6>About Website</h6>
              <p class="p-small">
                Aliquam ultrices turpis a auctor commodo. Etiam consectetur
                tincidunt elit ac euismod. Duis et finibus felis, non porttitor
                dolor
              </p>
            </div>
            <!-- end of footer-col -->
            <div class="footer-col second">
              <h6>Links</h6>
              <ul class="list-unstyled li-space-lg p-small">
                <li>
                  Important: <a href="terms.html">Terms & Conditions</a>,
                  <a href="privacy.html">Privacy Policy</a>
                </li>
                <li>
                  Useful: <a href="#">Colorpicker</a>,
                  <a href="#">Icon Library</a>, <a href="#">Illustrations</a>
                </li>
                <li>
                  Menu: <a href="index.html">Home</a>,
                  <a href="#solutions">Solutions</a>,
                  <a href="#expertise">Expertise</a>,
                  <a href="#projects">Projects</a>
                </li>
              </ul>
            </div>
            <!-- end of footer-col -->
            <div class="footer-col third">
              <span class="fa-stack">
                <a href="#your-link">
                  <i class="fas fa-circle fa-stack-2x"></i>
                  <i class="fab fa-facebook-f fa-stack-1x"></i>
                </a>
              </span>
              <span class="fa-stack">
                <a href="#your-link">
                  <i class="fas fa-circle fa-stack-2x"></i>
                  <i class="fab fa-twitter fa-stack-1x"></i>
                </a>
              </span>
              <span class="fa-stack">
                <a href="#your-link">
                  <i class="fas fa-circle fa-stack-2x"></i>
                  <i class="fab fa-pinterest-p fa-stack-1x"></i>
                </a>
              </span>
              <span class="fa-stack">
                <a href="#your-link">
                  <i class="fas fa-circle fa-stack-2x"></i>
                  <i class="fab fa-instagram fa-stack-1x"></i>
                </a>
              </span>
              <p class="p-small">
                Quam posuerei pellent esque vam
                <a href="mailto:contact@site.com"
                  ><strong>contact@site.com</strong></a
                >
              </p>
            </div>
            <!-- end of footer-col -->
          </div>
          <!-- end of col -->
        </div>
        <!-- end of row -->
      </div>
      <!-- end of container -->
    </div>
    <!-- end of footer -->
    <!-- end of footer -->

    <!-- Copyright -->
    <div class="copyright">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <p class="p-small">
              Copyright © <a href="#your-link">Your name</a>
            </p>
          </div>
          <!-- end of col -->
        </div>
        <!-- enf of row -->
      </div>
      <!-- end of container -->
    </div>
    <!-- end of copyright -->
    <!-- end of copyright -->

    <!-- Back To Top Button -->
    <button onclick="topFunction()" id="myBtn">
      <img src="images/up-arrow.png" alt="alternative" />
    </button>
    <!-- end of back to top button -->

    <!-- Scripts -->
    <script src="js/bootstrap.min.js"></script>
    <!-- Bootstrap framework -->
    <script src="js/swiper.min.js"></script>
    <!-- Swiper for image and text sliders -->
    <script src="js/purecounter.min.js"></script>
    <!-- Purecounter counter for statistics numbers -->
    <script src="js/replaceme.min.js"></script>
    <!-- ReplaceMe for rotating text -->
    <script src="js/isotope.pkgd.min.js"></script>
    <!-- Isotope for filter -->
    <script src="js/scripts.js"></script>
    <!-- Custom scripts -->
  </body>
</html>
